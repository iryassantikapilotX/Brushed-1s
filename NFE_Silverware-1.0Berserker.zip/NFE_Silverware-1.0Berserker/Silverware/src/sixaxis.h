
void sixaxis_init( void);
int sixaxis_check( void);
void sixaxis_read( void);
void gyro_read( void);
void gyro_cal( void);

void acc_cal(void);




