
int flash2_fmc_write( int data1 , int data2);
int flash2_readdata( unsigned int data );






